# PaintLab Beauty - SUPER EASY Deployment (GitHub + Vercel + Render)

## Why This is Easier Than cPanel

| cPanel | GitHub + Vercel |
|--------|-----------------|
| Manual file uploads | Automatic from GitHub |
| Need to configure .htaccess | Vercel handles routing automatically |
| FTP/File Manager | Just push to GitHub |
| Manual updates | Auto-deploy on every push |

**This method: Push code → Auto deploy → Done!**

---

## Step 1: Create GitHub Repository (5 minutes)

### Option A: Use GitHub Website (Easiest)

1. Go to https://github.com
2. Sign up or log in
3. Click the **+** button (top right) → **"New repository"**
4. Name it: `paintlab-beauty`
5. Make it **Public** or **Private** (your choice)
6. Click **"Create repository"**

### Option B: Upload Files Directly

1. On your new repo page, click **"uploading an existing file"**
2. Drag and drop ALL files from `/mnt/okcomputer/output/app/`
3. Add commit message: "Initial commit"
4. Click **"Commit changes"**

**That's it! Your code is now on GitHub.**

---

## Step 2: Deploy Frontend to Vercel (5 minutes)

Vercel is **FREE** and made by the creators of Next.js. It's the easiest deployment platform.

### Deploy in 3 Clicks:

1. Go to https://vercel.com
2. Sign up with **GitHub** (one click)
3. Click **"Add New Project"**
4. Select your `paintlab-beauty` repository
5. Vercel auto-detects it's a Vite/React app
6. Click **"Deploy"**

**Done! Your site is live in 1-2 minutes!**

Vercel automatically:
- ✅ Builds your app
- ✅ Handles routing (no 404 errors!)
- ✅ Gives you a free SSL certificate
- ✅ Provides a free domain (you can add your own later)

---

## Step 3: Deploy Backend to Render (5 minutes)

Render has a **FREE tier** perfect for your backend.

### Steps:

1. Go to https://render.com
2. Sign up with **GitHub**
3. Click **"New +"** → **"Web Service"**
4. Select your `paintlab-beauty` repository
5. Configure:
   - **Name:** `paintlab-api`
   - **Root Directory:** `backend`
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
6. Click **"Create Web Service"**

### Add Environment Variables:

1. In your Render dashboard, click your service
2. Go to **"Environment"** tab
3. Add these variables:

```
STRIPE_SECRET_KEY=sk_live_your_actual_key_here
STRIPE_PUBLISHABLE_KEY=pk_live_your_actual_key_here
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret_here
CASHAPP_CASHTAG=$Keeta424
CASHAPP_ENABLED=true
CORS_ORIGIN=https://your-vercel-domain.vercel.app
```

4. Click **"Save Changes"**

**Your backend will deploy in 2-3 minutes!**

---

## Step 4: Connect Frontend to Backend

### Update Environment Variable in Vercel:

1. Go to https://vercel.com/dashboard
2. Click your `paintlab-beauty` project
3. Go to **"Settings"** → **"Environment Variables"**
4. Add:

```
VITE_API_URL=https://your-render-url.onrender.com
```

5. Click **"Save"**
6. Go to **"Deployments"** tab
7. Click the **...** menu on latest deployment
8. Click **"Redeploy"**

**Done! Your frontend now connects to your backend!**

---

## Your Setup Will Look Like:

```
GitHub Repository
    ├── Frontend (React/Vite)
    │   └── Auto-deploys to Vercel
    └── Backend (Node.js/Express)
        └── Auto-deploys to Render
```

---

## Quick Reference

| Service | Purpose | Cost | URL |
|---------|---------|------|-----|
| GitHub | Code storage | Free | github.com |
| Vercel | Frontend hosting | Free | vercel.com |
| Render | Backend hosting | Free | render.com |
| Stripe | Payments | Pay per transaction | stripe.com |

---

## Updating Your Site (Super Easy!)

When you want to make changes:

1. Edit files locally
2. Push to GitHub: `git push`
3. Vercel automatically redeploys!

**No manual uploads, no cPanel, no FTP!**

---

## Common Issues & Solutions

### "Build Failed" on Vercel?
- Check the build logs in Vercel dashboard
- Usually a missing import or TypeScript error

### Backend won't start on Render?
- Check the logs in Render dashboard
- Make sure environment variables are set

### Payments not working?
- Verify Stripe keys are correct (test vs live)
- Check CORS_ORIGIN matches your Vercel URL

---

## Summary

| Step | Time | What You Do |
|------|------|-------------|
| 1. GitHub repo | 5 min | Create repo, upload files |
| 2. Vercel deploy | 5 min | Connect GitHub, click Deploy |
| 3. Render deploy | 5 min | Connect GitHub, add env vars |
| 4. Connect them | 2 min | Add API URL to Vercel |
| **Total** | **~17 min** | **Much easier than cPanel!** |

---

## Need Help?

- **Vercel Docs:** https://vercel.com/docs
- **Render Docs:** https://render.com/docs
- **GitHub Docs:** https://docs.github.com

---

**This is the easiest way to deploy! No cPanel, no manual uploads, no .htaccess files. Just push to GitHub and everything deploys automatically!** 🚀
