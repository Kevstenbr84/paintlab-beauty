# PaintLab Beauty - Deployment Guide

## Frontend Deployed
Your frontend is now live at: **https://7lae6rrlexlkw.ok.kimi.link**

---

## Backend Deployment (Required for Payments)

The backend API needs to be deployed separately to handle Stripe payments, webhooks, and CashApp integration.

### Option 1: Render (Recommended - Free Tier Available)

1. **Create a Render account** at https://render.com
2. **Create a new Web Service**
3. **Connect your GitHub repo** or upload the backend folder
4. **Configure settings:**
   - Build Command: `npm install`
   - Start Command: `npm start`
   - Root Directory: `backend`

5. **Add Environment Variables:**
   ```
   PORT=10000
   STRIPE_SECRET_KEY=sk_live_your_actual_stripe_secret_key
   STRIPE_PUBLISHABLE_KEY=pk_live_your_actual_stripe_publishable_key
   STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret
   CASHAPP_CASHTAG=$Keeta424
   CASHAPP_ENABLED=true
   CORS_ORIGIN=https://7lae6rrlexlkw.ok.kimi.link
   ```

6. **Get your backend URL** (e.g., `https://paintlab-api.onrender.com`)

---

### Option 2: Railway (Free Tier Available)

1. **Create account** at https://railway.app
2. **New Project** → Deploy from GitHub
3. **Add environment variables** (same as above)
4. **Deploy**

---

### Option 3: Vercel Serverless Functions

The backend can also be deployed to Vercel as serverless functions.

---

## Stripe Configuration

### 1. Get Your Stripe Keys
- Go to https://dashboard.stripe.com/apikeys
- Copy your **Publishable key** (starts with `pk_live_` or `pk_test_`)
- Copy your **Secret key** (starts with `sk_live_` or `sk_test_`)

### 2. Configure Webhook Endpoint
1. Go to https://dashboard.stripe.com/webhooks
2. Click "Add endpoint"
3. Enter your backend URL: `https://your-backend-url.com/webhook`
4. Select events to listen for:
   - `payment_intent.succeeded`
   - `payment_intent.payment_failed`
   - `checkout.session.completed`
   - `account.updated` (for Connect)
5. Copy the **Webhook signing secret** (starts with `whsec_`)

### 3. Enable CashApp Pay in Stripe
1. Go to https://dashboard.stripe.com/settings/payment_methods
2. Enable "Cash App Pay" in your payment methods
3. This allows customers to pay with CashApp through Stripe

---

## CashApp Pay Configuration

Your CashApp Pay is configured with:
- **Cashtag:** $Keeta424
- **Payment Method:** Direct CashApp link + QR Code generation

When customers select CashApp Pay at checkout:
1. A QR code is generated linking directly to your CashApp
2. Customers can scan and pay instantly
3. Payment confirmation is handled via webhook

---

## Environment Variables Reference

### Backend (.env file)
```env
# Server
PORT=10000

# Stripe (REQUIRED)
STRIPE_SECRET_KEY=sk_live_your_stripe_secret_key
STRIPE_PUBLISHABLE_KEY=pk_live_your_stripe_publishable_key
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret

# Stripe Connect (for marketplace/vendor payouts)
STRIPE_CONNECT_CLIENT_ID=ca_your_connect_client_id

# CashApp (configured for $Keeta424)
CASHAPP_CASHTAG=$Keeta424
CASHAPP_ENABLED=true

# Frontend URL (for CORS)
CORS_ORIGIN=https://7lae6rrlexlkw.ok.kimi.link

# Optional: Database (if you add Supabase later)
# DATABASE_URL=your_supabase_connection_string
```

### Frontend (.env file)
```env
VITE_API_URL=https://your-backend-url.com
VITE_STRIPE_PUBLISHABLE_KEY=pk_live_your_stripe_publishable_key
```

---

## Testing the Payment Flow

### Test Credit Card (Stripe Test Mode)
- Card Number: `4242 4242 4242 4242`
- Expiry: Any future date
- CVC: Any 3 digits
- ZIP: Any 5 digits

### Test CashApp Pay
1. Use Stripe's test mode
2. Select CashApp Pay at checkout
3. You'll be redirected to a simulated CashApp flow

---

## API Endpoints Available

### Payments
- `POST /api/create-payment-intent` - Create Stripe payment intent
- `POST /api/create-cashapp-payment` - Create CashApp-specific payment
- `POST /api/cashapp/generate-link` - Generate direct CashApp payment link

### Stripe Connect
- `POST /api/connect/create-account` - Create connected account
- `GET /api/connect/account-status/:accountId` - Check account status
- `POST /api/connect/create-login-link` - Create dashboard login link

### Webhooks
- `POST /webhook` - Stripe webhook handler

### Orders
- `POST /api/orders` - Create order
- `GET /api/orders/:orderId` - Get order details
- `PATCH /api/orders/:orderId/status` - Update order status

### Health
- `GET /health` - Health check endpoint

---

## Next Steps

1. **Deploy the backend** using one of the options above
2. **Add your Stripe keys** to the environment variables
3. **Configure the webhook endpoint** in Stripe Dashboard
4. **Update the frontend API URL** in the deployed frontend (if needed)
5. **Test a complete purchase flow**
6. **Set up your actual product catalog** in the admin dashboard

---

## Support

For issues with:
- **Stripe**: https://stripe.com/support
- **CashApp Business**: https://cash.app/help
- **Render**: https://render.com/docs

---

## Files Included

```
/mnt/okcomputer/output/app/
├── backend/
│   ├── server.js          # Main Express server
│   ├── package.json       # Backend dependencies
│   └── .env.example       # Environment template
├── src/
│   ├── lib/api.ts         # Frontend API client
│   ├── components/
│   │   ├── CashAppPay.tsx     # CashApp payment component
│   │   ├── StripeProvider.tsx # Stripe context provider
│   │   └── StripeCheckoutForm.tsx # Stripe card form
│   └── pages/
│       └── Checkout.tsx   # Updated checkout with payment selection
└── dist/                  # Built frontend (deployed)
```

Your e-commerce platform is ready! The frontend is live and the backend is ready to deploy with your Stripe credentials.
