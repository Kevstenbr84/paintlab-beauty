# PaintLab Beauty - cPanel Deployment Guide (Spaceship.com)

## Question 1: Why You're Seeing 404 Errors

**Yes, this is normal for Single Page Applications (SPAs)!** 

The 404 errors happen because:
- Your app is a React SPA that uses client-side routing
- When you click a link like `/products`, the browser tries to find a file at that path
- But there's only `index.html` - React handles the routing internally
- **The .htaccess file I created fixes this** - it tells Apache to serve index.html for all routes

---

## Step-by-Step cPanel Deployment (Spaceship.com)

### Step 1: Prepare Your Files

1. **Download the built files** from `/mnt/okcomputer/output/app/dist/`
   - These are already compiled and ready to upload
   - The `.htaccess` file is included for routing

2. **Create a ZIP file** of the `dist` folder contents:
   ```
   dist/
   ├── index.html
   ├── assets/
   ├── .htaccess (IMPORTANT!)
   └── admin-features/
   ```

---

### Step 2: Log into cPanel

1. Go to **Spaceship.com** and log in
2. Navigate to your hosting dashboard
3. Click **"cPanel"** or **"Manage Hosting"**
4. You'll see the cPanel dashboard with various icons

---

### Step 3: Upload Files via File Manager

1. In cPanel, find and click **"File Manager"**
2. Navigate to the `public_html` folder (this is your web root)
3. **If you have existing files:**
   - Select all files
   - Click "Delete" or move them to a backup folder
4. **Upload your files:**
   - Click **"Upload"** button (top toolbar)
   - Select your ZIP file or drag & drop
   - Wait for upload to complete
   - Click **"Go Back to..."**
5. **Extract the ZIP:**
   - Right-click on the uploaded ZIP file
   - Select **"Extract"**
   - Extract to `public_html/`
   - Delete the ZIP file after extraction

---

### Step 4: Verify File Structure

Your `public_html` should look like this:
```
public_html/
├── .htaccess          ← CRITICAL for routing
├── index.html         ← Main entry point
├── assets/            ← CSS, JS files
│   ├── index-xxx.css
│   └── index-xxx.js
└── admin-features/    ← Admin components
```

**Important:** The `.htaccess` file must be in the root of `public_html`

---

### Step 5: Test Your Website

1. Visit your domain: `https://yourdomain.com`
2. Click around - the 404 errors should be **GONE**
3. Test these routes:
   - Homepage: `/`
   - Products: `/products`
   - Cart: `/cart`
   - Checkout: `/checkout`
   - Admin: `/admin`

---

## Backend API Deployment (Node.js on cPanel)

### Option A: Use Spaceship's Node.js Support (If Available)

1. In cPanel, look for **"Setup Node.js App"** or **"Node.js"**
2. Click **"Create Application"**
3. Configure:
   - **Node.js version:** 18.x or higher
   - **Application root:** `backend`
   - **Application URL:** `api.yourdomain.com` or `yourdomain.com/api`
   - **Startup file:** `server.js`
4. Click **"Create"**
5. **Install dependencies:**
   - SSH into your server or use Terminal in cPanel
   - Run: `cd backend && npm install`
6. **Set environment variables:**
   - In cPanel, look for "Environment Variables"
   - Add your Stripe keys (see below)

### Option B: Use a Separate Hosting for Backend (Recommended)

Since cPanel shared hosting has limitations with Node.js, I recommend:

**Free Options:**
1. **Render.com** - https://render.com (Free tier)
2. **Railway.app** - https://railway.app (Free tier)
3. **Cyclic.sh** - https://cyclic.sh (Free)

**Steps for Render:**
1. Create account at render.com
2. New → Web Service
3. Upload your `backend` folder
4. Set environment variables (see below)
5. Deploy - you'll get a URL like `https://paintlab-api.onrender.com`

---

## Environment Variables Setup

### In cPanel (If Using Node.js App):

1. Go to **"Setup Node.js App"**
2. Click on your app
3. Find **"Environment Variables"** section
4. Add these variables:

```
STRIPE_SECRET_KEY=sk_live_your_actual_key_here
STRIPE_PUBLISHABLE_KEY=pk_live_your_actual_key_here
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret_here
CASHAPP_CASHTAG=$Keeta424
CASHAPP_ENABLED=true
CORS_ORIGIN=https://yourdomain.com
PORT=3000
```

### In Render/Railway:

1. Go to your service dashboard
2. Click **"Environment"** or **"Variables"**
3. Add the same variables as above

---

## Getting Your Stripe Keys

### Step 1: Get API Keys
1. Go to https://dashboard.stripe.com/apikeys
2. Copy **Publishable key** (starts with `pk_live_` or `pk_test_`)
3. Copy **Secret key** (starts with `sk_live_` or `sk_test_`)
4. **Keep the Secret key PRIVATE!**

### Step 2: Setup Webhook
1. Go to https://dashboard.stripe.com/webhooks
2. Click **"Add endpoint"**
3. Enter your backend URL: `https://your-api-url.com/webhook`
4. Select events:
   - `payment_intent.succeeded`
   - `payment_intent.payment_failed`
   - `checkout.session.completed`
5. Copy the **Webhook signing secret** (starts with `whsec_`)

### Step 3: Enable CashApp Pay
1. Go to https://dashboard.stripe.com/settings/payment_methods
2. Find **"Cash App Pay"**
3. Toggle it **ON**

---

## Final Completion Checklist

### Frontend (cPanel) ✅
- [ ] Files uploaded to `public_html`
- [ ] `.htaccess` file in place
- [ ] Website loads without 404 errors
- [ ] All navigation links work
- [ ] Admin dashboard accessible

### Backend (Render/Railway/cPanel) ✅
- [ ] Backend deployed and running
- [ ] Environment variables configured
- [ ] Stripe keys added
- [ ] Webhook endpoint configured in Stripe
- [ ] CashApp Pay enabled in Stripe

### Payment Testing ✅
- [ ] Test credit card payment (use 4242 4242 4242 4242)
- [ ] Test CashApp Pay flow
- [ ] Verify order appears in admin
- [ ] Check webhook events in Stripe dashboard

### Content & Products ✅
- [ ] Add your actual products in admin
- [ ] Upload product images
- [ ] Set prices and inventory
- [ ] Configure shipping rates
- [ ] Add business info (address, contact)

### Legal & Compliance ✅
- [ ] Add Privacy Policy page
- [ ] Add Terms of Service page
- [ ] Add Refund/Return Policy
- [ ] Add Shipping Policy
- [ ] Configure tax settings

---

## Troubleshooting

### 404 Errors Still Appearing?
1. Check that `.htaccess` exists in `public_html`
2. Make sure Apache `mod_rewrite` is enabled
3. Try clearing browser cache (Ctrl+Shift+R)
4. Check cPanel → Apache Modules → mod_rewrite

### Backend Not Connecting?
1. Verify `VITE_API_URL` in frontend matches your backend URL
2. Check CORS settings in backend
3. Test backend health endpoint: `https://your-api.com/health`

### Stripe Payments Failing?
1. Verify keys are correct (test vs live mode)
2. Check webhook secret matches
3. Review Stripe Dashboard → Developers → Logs
4. Ensure CashApp Pay is enabled in Stripe settings

---

## TurboTax Export Feature

I've created a **Tax Export component** for your admin dashboard:

**Location:** `admin-features/TaxExport.tsx`

**Features:**
- Export all orders to CSV
- Generate TurboTax-compatible summary
- Export in TXF format
- Filter by tax year
- Calculate totals automatically

**To use:**
1. Go to Admin Dashboard
2. Navigate to "Tax Export" section
3. Select tax year
4. Click export format
5. Import CSV into TurboTax

---

## Credentials Manager Feature

I've also created a **Credentials Manager** for easy key management:

**Location:** `admin-features/CredentialsManager.tsx`

**Features:**
- Add Stripe keys from admin dashboard
- Configure CashApp Pay settings
- Test Stripe connection
- Secure key storage
- Quick links to Stripe dashboard

**To use:**
1. Go to Admin Dashboard
2. Navigate to "Settings" → "Credentials"
3. Enter your keys
4. Save and test connection

---

## Summary

| Task | Location | Status |
|------|----------|--------|
| Frontend Files | `dist/` folder | Ready to upload |
| .htaccess | `dist/.htaccess` | Fixes 404 errors |
| Backend API | `backend/` folder | Deploy separately |
| Tax Export | `admin-features/TaxExport.tsx` | Ready to integrate |
| Credentials Manager | `admin-features/CredentialsManager.tsx` | Ready to integrate |

---

## Support Resources

- **Spaceship cPanel Help:** https://spaceship.com/support
- **Stripe Documentation:** https://stripe.com/docs
- **TurboTax Business:** https://turbotax.intuit.com/business
- **Apache mod_rewrite:** https://httpd.apache.org/docs/current/mod/mod_rewrite.html

---

**Your website is ready to deploy!** Follow these steps and you'll have a fully functional e-commerce site with Stripe and CashApp payments on your Spaceship hosting.
