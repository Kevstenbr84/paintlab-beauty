# PaintLab Beauty - E-Commerce Platform

A modern, high-conversion e-commerce platform for a beauty brand targeting Gen Z and Millennial women.

![PaintLab Beauty](https://your-screenshot-url.com)

## Features

### Storefront
- Stunning hero section with Spring Daze collection
- Product catalog with variant selection
- 3D product preview with Three.js
- Shopping cart with slide-out drawer
- Full checkout flow
- Responsive design

### Admin Dashboard
- **Dashboard**: Revenue, orders, customer analytics
- **Theme Editor**: Drag-and-drop UI blocks, 50+ Google Fonts, color customization
- **Inventory Management**: Low stock alerts, predicted demand, bulk editing
- **Order Management**: Fulfillment workflow, order details, status tracking
- **Analytics**: Revenue charts, customer retention, heatmaps
- **AI Chatbot**: Natural language to SQL queries
- **Marketing Tools**: Spin to Win, Loyalty Program, AI Nail Quiz

## Tech Stack

- **Frontend**: React + TypeScript + Vite
- **Styling**: Tailwind CSS + shadcn/ui
- **State Management**: Zustand
- **Animations**: Framer Motion
- **3D Graphics**: Three.js + React Three Fiber
- **Charts**: Recharts

## Getting Started

### Prerequisites
- Node.js 18+
- npm or yarn

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/paintlab-beauty.git
cd paintlab-beauty

# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

### Environment Variables

Create a `.env` file in the root directory:

```env
# Supabase (optional - for backend integration)
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key

# Stripe (optional - for payments)
VITE_STRIPE_PUBLIC_KEY=your_stripe_public_key
```

## Deployment

### Option 1: Vercel (Recommended)

1. Push your code to GitHub
2. Connect your GitHub repo to Vercel
3. Deploy automatically on every push

### Option 2: Netlify

1. Push your code to GitHub
2. Connect your GitHub repo to Netlify
3. Set build command: `npm run build`
4. Set publish directory: `dist`

### Option 3: Your Own Hosting

1. Run `npm run build`
2. Upload the `dist` folder to your web server
3. Configure your server to serve `index.html` for all routes (SPA)

## Admin Access

Navigate to `/admin` to access the admin dashboard.

## License

MIT License - feel free to use this for your own projects!
