# PaintLab Beauty - Quick Start Checklist

## Phase 1: Deploy Frontend to cPanel (Spaceship)

```
□ Log into Spaceship.com
□ Go to cPanel
□ Open File Manager
□ Navigate to public_html/
□ Delete old files (or backup)
□ Upload all files from /dist/ folder
□ Verify .htaccess exists in public_html/
□ Visit your domain and test links
```

**Expected Result:** Website loads, no 404 errors when clicking tabs

---

## Phase 2: Get Stripe Keys

```
□ Go to dashboard.stripe.com
□ Sign up or log in
□ Go to Developers → API Keys
□ Copy Publishable Key (pk_live_...)
□ Reveal and copy Secret Key (sk_live_...)
□ Go to Developers → Webhooks
□ Add endpoint: https://your-backend.com/webhook
□ Select events: payment_intent.succeeded, payment_intent.payment_failed
□ Copy Webhook Secret (whsec_...)
□ Go to Settings → Payment Methods
□ Enable "Cash App Pay"
```

---

## Phase 3: Deploy Backend (Render.com - Free)

```
□ Go to render.com
□ Sign up with GitHub
□ Click "New +" → "Web Service"
□ Upload backend/ folder
□ Set environment variables:
   STRIPE_SECRET_KEY=sk_live_...
   STRIPE_PUBLISHABLE_KEY=pk_live_...
   STRIPE_WEBHOOK_SECRET=whsec_...
   CASHAPP_CASHTAG=$Keeta424
   CASHAPP_ENABLED=true
   CORS_ORIGIN=https://yourdomain.com
□ Click "Create Web Service"
□ Wait for deployment
□ Copy the service URL
```

---

## Phase 4: Connect Frontend to Backend

```
□ Go to Admin Dashboard
□ Navigate to Settings → Credentials
□ Enter Stripe Publishable Key
□ Enter Backend API URL
□ Click "Save Credentials"
□ Click "Test Stripe Connection"
□ Verify connection is successful
```

---

## Phase 5: Test Payments

```
□ Add a test product
□ Go to storefront
□ Add product to cart
□ Go to checkout
□ Fill in shipping info
□ Select "Credit Card" payment
□ Enter test card: 4242 4242 4242 4242
□ Enter expiry: 12/30
□ Enter CVC: 123
□ Complete purchase
□ Check order appears in admin
```

---

## Phase 6: Test CashApp Pay

```
□ Add product to cart
□ Go to checkout
□ Select "CashApp Pay"
□ Scan QR code or click "Open CashApp"
□ Complete payment in CashApp
□ Verify order appears in admin
```

---

## Phase 7: Add Your Products

```
□ Go to Admin Dashboard
□ Click "Products" tab
□ Click "Add Product"
□ Enter product name
□ Upload product images
□ Set price
□ Set inventory quantity
□ Add description
□ Save product
□ Repeat for all products
```

---

## Phase 8: Configure Store Settings

```
□ Set store name
□ Add business address
□ Configure shipping rates
□ Set tax rates
□ Add contact email
□ Add social media links
```

---

## Phase 9: Legal Pages

```
□ Create Privacy Policy page
□ Create Terms of Service page
□ Create Return/Refund Policy page
□ Create Shipping Policy page
□ Add links to footer
```

**Free generators:**
- Privacy Policy: termsfeed.com/privacy-policy-generator
- Terms of Service: termsfeed.com/terms-conditions-generator

---

## Phase 10: Tax Setup (TurboTax Export)

```
□ Go to Admin Dashboard
□ Click "Tax Export" tab
□ Select tax year
□ Click "TurboTax Summary"
□ Download CSV file
□ Open TurboTax Business
□ Import or enter values
```

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| 404 on page refresh | Check .htaccess exists |
| Payments not working | Verify Stripe keys are correct |
| Backend not connecting | Check CORS_ORIGIN matches your domain |
| CashApp not showing | Enable in Stripe Dashboard |
| Orders not appearing | Check webhook is configured |

---

## Important URLs

| Service | URL |
|---------|-----|
| Stripe Dashboard | dashboard.stripe.com |
| Stripe API Keys | dashboard.stripe.com/apikeys |
| Stripe Webhooks | dashboard.stripe.com/webhooks |
| Render Dashboard | dashboard.render.com |
| Spaceship cPanel | Your hosting panel |

---

## Your Configuration

**CashApp Cashtag:** $Keeta424

**Frontend URL:** https://yourdomain.com

**Backend URL:** https://your-backend.onrender.com

**Stripe Webhook URL:** https://your-backend.onrender.com/webhook

---

## Files to Keep Safe

```
□ Stripe Secret Key (sk_live_...)
□ Stripe Webhook Secret (whsec_...)
□ Backend API credentials
□ Database passwords (if added later)
```

**Never share these or commit to Git!**

---

## You're Ready to Launch! 🚀

Once all boxes are checked, your PaintLab Beauty e-commerce site is ready to accept real customers and payments!
