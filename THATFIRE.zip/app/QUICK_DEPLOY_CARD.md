# 🚀 QUICK DEPLOY CARD

## The 3-Platform Method (EASIEST)

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   GITHUB    │────▶│   VERCEL    │     │   RENDER    │
│  (Storage)  │     │  (Website)  │     │  (Backend)  │
└─────────────┘     └─────────────┘     └─────────────┘
                            │                    │
                            └────────────────────┘
                                    │
                                    ▼
                           ┌─────────────┐
                           │    LIVE     │
                           │   WEBSITE   │
                           └─────────────┘
```

---

## Step 1: GitHub (5 min)

**URL:** github.com

**Do this:**
1. Sign up
2. Click "New repository"
3. Name: `paintlab-beauty`
4. Upload all your files
5. Click "Commit changes"

**Result:** ✅ Code is saved

---

## Step 2: Vercel (5 min)

**URL:** vercel.com/signup

**Do this:**
1. Sign up with GitHub
2. Click "Add New Project"
3. Select `paintlab-beauty`
4. Click "Deploy"

**Result:** ✅ Website is LIVE at `yourname.vercel.app`

---

## Step 3: Render (5 min)

**URL:** dashboard.render.com

**Do this:**
1. Sign up with GitHub
2. Click "New +" → "Web Service"
3. Select `paintlab-beauty`
4. Set Root Directory: `backend`
5. Click "Create Web Service"
6. Add environment variables (see below)

**Result:** ✅ Backend API is LIVE

---

## Environment Variables for Render

Click "Environment" tab, add these:

```
STRIPE_SECRET_KEY=sk_live_...
STRIPE_PUBLISHABLE_KEY=pk_live_...
CASHAPP_CASHTAG=$Keeta424
CASHAPP_ENABLED=true
CORS_ORIGIN=https://your-vercel-url.vercel.app
```

---

## Connect Frontend to Backend

In Vercel:
1. Settings → Environment Variables
2. Add: `VITE_API_URL=https://your-render-url.onrender.com`
3. Save
4. Redeploy

---

## Done! 🎉

| What | URL |
|------|-----|
| Your Website | `https://yourname.vercel.app` |
| Your API | `https://paintlab-api.onrender.com` |
| Your Code | `https://github.com/yourname/paintlab-beauty` |

---

## To Update Later

Just push to GitHub → Vercel auto-updates!

```bash
git add .
git commit -m "updates"
git push
```

---

## Why This is Better Than cPanel

| Feature | cPanel | GitHub+Vercel+Render |
|---------|--------|---------------------|
| File uploads | Manual drag & drop | Automatic from GitHub |
| 404 errors | Need .htaccess file | Handled automatically |
| SSL certificate | Manual setup | Free & automatic |
| Updates | Re-upload all files | Push to GitHub |
| Difficulty | Hard | Easy |

---

**Questions? Just ask!**
