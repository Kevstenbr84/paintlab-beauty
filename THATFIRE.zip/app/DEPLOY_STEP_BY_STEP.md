# DEPLOY IN 15 MINUTES - Step by Step

## NO CPANEL. NO FTP. NO MANUAL UPLOADS.

---

## PART 1: GitHub (Save Your Code)

### Step 1.1: Create Account
- Go to https://github.com/signup
- Enter email, create password
- Verify email
- **DONE**

### Step 1.2: Create Repository
- Click **GREEN BUTTON** "Create repository" (or + → New repository)
- Repository name: `paintlab-beauty`
- Click **"Create repository"**
- **DONE**

### Step 1.3: Upload Your Files
- On the new page, click **"uploading an existing file"** (blue link)
- Click **"choose your files"**
- Select ALL files from the `app` folder I gave you
- Wait for upload to finish
- Scroll down, click **"Commit changes"**
- **DONE - Your code is saved!**

---

## PART 2: Vercel (Your Website Goes Live)

### Step 2.1: Create Account
- Go to https://vercel.com/signup
- Click **"Continue with GitHub"**
- Authorize Vercel
- **DONE**

### Step 2.2: Deploy Your Site
- Click **"Add New..."** → **"Project"**
- Find `paintlab-beauty` in the list
- Click **"Import"**
- Framework Preset: Should auto-detect "Vite"
- Click **"Deploy"**
- Wait 1-2 minutes
- **DONE - Your site is LIVE!**

**Copy the URL** (looks like `paintlab-beauty.vercel.app`)

---

## PART 3: Render (Backend API)

### Step 3.1: Create Account
- Go to https://dashboard.render.com
- Click **"Get Started"** or **"Sign Up"**
- Click **"Sign up with GitHub"**
- **DONE**

### Step 3.2: Deploy Backend
- Click **"New +"** (top right)
- Click **"Web Service"**
- Find `paintlab-beauty` repo
- Click **"Connect"**

### Step 3.3: Configure
Fill in these fields:

| Field | Value |
|-------|-------|
| Name | `paintlab-api` |
| Root Directory | `backend` |
| Runtime | `Node` |
| Build Command | `npm install` |
| Start Command | `npm start` |

Click **"Create Web Service"**

Wait 2-3 minutes for deployment

**Copy the URL** (looks like `paintlab-api.onrender.com`)

---

## PART 4: Add Your Stripe Keys

### Step 4.1: Get Keys from Stripe
- Go to https://dashboard.stripe.com/apikeys
- Copy **Publishable key** (starts with `pk_`)
- Click "Reveal" on Secret key
- Copy **Secret key** (starts with `sk_`)

### Step 4.2: Add Keys to Render
- Go to https://dashboard.render.com
- Click your `paintlab-api` service
- Click **"Environment"** tab
- Click **"Add Environment Variable"**

Add these one by one:

```
Key: STRIPE_SECRET_KEY
Value: sk_live_your_key_here

Key: STRIPE_PUBLISHABLE_KEY  
Value: pk_live_your_key_here

Key: CASHAPP_CASHTAG
Value: $Keeta424

Key: CASHAPP_ENABLED
Value: true

Key: CORS_ORIGIN
Value: https://your-vercel-url.vercel.app
```

Click **"Save Changes"**

Render will auto-redeploy!

---

## PART 5: Connect Frontend to Backend

### Step 5.1: Add API URL to Vercel
- Go to https://vercel.com/dashboard
- Click your `paintlab-beauty` project
- Click **"Settings"** tab
- Click **"Environment Variables"**
- Click **"Add"**

```
Name: VITE_API_URL
Value: https://your-render-url.onrender.com
```

Click **"Save"**

### Step 5.2: Redeploy
- Go to **"Deployments"** tab
- Find the latest deployment
- Click the **3 dots** (⋯)
- Click **"Redeploy"**

**DONE! Everything is connected!**

---

## WHAT YOU NOW HAVE

| Service | URL | Purpose |
|---------|-----|---------|
| GitHub | github.com/yourname/paintlab-beauty | Code storage |
| Vercel | paintlab-beauty.vercel.app | Your LIVE website |
| Render | paintlab-api.onrender.com | Payment processing |

---

## WHEN YOU WANT TO UPDATE

Just edit files and push to GitHub:

```bash
git add .
git commit -m "My changes"
git push
```

**Vercel automatically redeploys!**

---

## NEED TO UPDATE STRIPE KEYS?

1. Go to https://dashboard.render.com
2. Click your `paintlab-api` service
3. Click **"Environment"** tab
4. Edit the variables
5. Click **Save**
6. Render auto-redeploys!

---

## TOTAL TIME: ~15 MINUTES

| Part | Time |
|------|------|
| GitHub | 5 min |
| Vercel | 5 min |
| Render | 5 min |
| **Total** | **15 min** |

**No cPanel. No file uploads. No configuration files. Just click, click, done!** 🎉
